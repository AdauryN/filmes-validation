package com.CineMeetServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineMeetServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CineMeetServerApplication.class, args);
	}

}
