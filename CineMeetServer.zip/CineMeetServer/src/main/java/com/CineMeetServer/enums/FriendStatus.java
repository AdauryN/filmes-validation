package com.CineMeetServer.enums;

public enum FriendStatus {

    PENDING,
    ACCEPTED,
    REJECTED
}
