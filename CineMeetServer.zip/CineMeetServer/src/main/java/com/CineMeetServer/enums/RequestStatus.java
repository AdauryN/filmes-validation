package com.CineMeetServer.enums;

public enum RequestStatus {

    PENDING,
    APPROVED,
    DISAPPROVED
}
