package com.CineMeetServer.enums;

public enum UserRole {
    ADMIN,
    USER
}
